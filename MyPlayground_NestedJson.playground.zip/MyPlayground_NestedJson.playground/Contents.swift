import UIKit

var str = "Hello, playground"

var jsonStr = """
[
    {
        "id": "0001",
        "type": "donut",
        "name": "Cake",
        "ppu": 0.55,
        "batters":
            {
                "batter":
                    [
                        { "id": "1001", "type": "Regular" },
                        { "id": "1002", "type": "Chocolate" },
                        { "id": "1003", "type": "Blueberry" },
                        { "id": "1004", "type": "Devil's Food" }
                    ]
            },
        "topping":
            [
                { "id": "5001", "type": "None" },
                { "id": "5002", "type": "Glazed" },
                { "id": "5005", "type": "Sugar" },
                { "id": "5007", "type": "Powdered Sugar" },
                { "id": "5006", "type": "Chocolate with Sprinkles" },
                { "id": "5003", "type": "Chocolate" },
                { "id": "5004", "type": "Maple" }
            ]
    },
    {
        "id": "0002",
        "type": "donut",
        "name": "Raised",
        "ppu": 0.55,
        "batters":
            {
                "batter":
                    [
                        { "id": "1001", "type": "Regular" }
                    ]
            },
        "topping":
            [
                { "id": "5001", "type": "None" },
                { "id": "5002", "type": "Glazed" },
                { "id": "5005", "type": "Sugar" },
                { "id": "5003", "type": "Chocolate" },
                { "id": "5004", "type": "Maple" }
            ]
    },
    {
        "id": "0003",
        "type": "donut",
        "name": "Old Fashioned",
        "ppu": 0.55,
        "batters":
            {
                "batter":
                    [
                        { "id": "1001", "type": "Regular" },
                        { "id": "1002", "type": "Chocolate" }
                    ]
            },
        "topping":
            [
                { "id": "5001", "type": "None" },
                { "id": "5002", "type": "Glazed" },
                { "id": "5003", "type": "Chocolate" },
                { "id": "5004", "type": "Maple" }
            ]
    }
]
"""

//print(jsonStr)

let data = jsonStr.data(using: .utf8)!
do {
    if let jsonArray = try JSONSerialization.jsonObject(with: data, options : .allowFragments) as? [Dictionary<String,Any>]
    {
     //  print("JSON = \(jsonArray)") // use the json here
        print(jsonArray.count)
     
        for arrdata in jsonArray{
            let battData = arrdata["batters"] as? Dictionary<String,Any>
            print("batters \(battData)")
            
            print("hhhhh : \(battData?["batter"])")
            let battData1 = battData?["batter"] as? Array<Any>
            print("better \(battData1)")
            
            for indata in battData1!{
                let battData = indata as? Dictionary<String,String>

                let battData2 = battData?["type"]
                print("FINAL  \(battData2)")
                
            }

//            let battData2 = battData1?[0] as? Dictionary<String,String>
//
//            print(" data = \(battData2?["type"] ?? "")")//["better"]?[0]
            
        }
      
    } else {
        print("bad json")
    }
} catch let error as NSError {
    print(error)
}

